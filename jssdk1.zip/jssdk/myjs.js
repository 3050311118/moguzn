var openid=localStorage.getItem('openid')
var devid=localStorage.getItem('devid')
var tempdev=localStorage.getItem("tempdev")
var tempname=localStorage.getItem("tempname")
var devlist={"":""}
var pageIndex=0;

if(localStorage.getItem('devlist') !== null)
{
    devlist=JSON.parse(localStorage.getItem('devlist'));
}

// if(openid === null) {window.location.href="/wxlogin"}
// if(devid === null) {devid="aaa"}
var mqtt;  
var subtopic = devid+"/sub"
var wxpubtopic = openid+"/wxpub"
var wxsubtopic = openid+"/wxsub"
var wxdevtopic = openid+"/"+tempname+"/wxsub"
var reconnectTimeout = 2000;  

function MQTTconnect(page) {
    pageIndex=page  
    mqtt = new Paho.MQTT.Client(  
                    "www.mogudz.com",  
                    8083,  
                    "web_" + openid);  
    var options = {  
        timeout: 10000,  
        cleanSession: true,  
        onSuccess: onConnect, 
        onFailure: function (message) {  
            alert("服务器连接错误!")
            setTimeout(MQTTconnect, reconnectTimeout); 
        }  
    };  

    mqtt.onConnectionLost = onConnectionLost;  
    mqtt.onMessageArrived = onMessageArrived;  
    mqtt.connect(options);  
}  

var onConnectCount=0;
function onConnect() {  
   console.log("onConnect") 
   mqtt.subscribe(wxpubtopic, {qos: 0});
   if(pageIndex===1){
       if(onConnectCount===0){
            var arr={"t":"online","i":openid}
            MqttSend(wxsubtopic,JSON.stringify(arr)); 
       }
       onConnectCount=1;
   }else if(pageIndex===2){
       var arr={"t":"info","i":openid}
       MqttSend(wxdevtopic,JSON.stringify(arr));    
   }
}  

function onConnectionLost(response) {  
    setTimeout(MQTTconnect, reconnectTimeout);
}

function MqttSend(topic,content){  
    var str = CryptoJS.enc.Utf8.parse(content);
    var base64 = CryptoJS.enc.Base64.stringify(str);
    var message = new Paho.MQTT.Message(base64);  
    message.destinationName = topic;  
    message.qos=0;  
    mqtt.send(message);   
} 
function jsonop(json,prop, val) {
    if(typeof val === "undefined") {
        delete json[prop];
    }else {
        json[prop] = val;
    }
}